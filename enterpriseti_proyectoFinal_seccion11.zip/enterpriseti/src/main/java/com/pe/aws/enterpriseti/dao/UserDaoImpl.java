package com.pe.aws.enterpriseti.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.StoredProcedureQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.pe.aws.enterpriseti.entity.Usuario;

@Repository("usuarioDao")
@Transactional
public class UserDaoImpl implements UserDao  {
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<Usuario> getListUser() {
		// TODO Auto-generated method stub
		String hql="FROM Usuario";
		return (List<Usuario>)entityManager.createQuery(hql).getResultList();
	}

	@Override
	public Long addUser(Usuario user) {
		// TODO Auto-generated method stub
		entityManager.persist(user);
		
		return user.getUsuarioId();
	}

	@Override
	public Usuario getUser(Long id) {
		// TODO Auto-generated method stub
		return entityManager.find(Usuario.class, id);
	}

	@Override
	public boolean deleteUser(Long id) {
		// TODO Auto-generated method stub
		boolean flagComplete=false;
		entityManager.remove(getUser(id));
		flagComplete=true;
		return flagComplete;
	}

	@Override
	public boolean updateUser(Long id, Usuario user) {
		// TODO Auto-generated method stub
		boolean flagComplete=false;
		Usuario usuario = getUser(id);
		usuario.setUsuarioAlias(user.getUsuarioAlias());
		usuario.setUsuarioDni(user.getUsuarioDni());
		usuario.setUsuarioEmail(user.getUsuarioEmail());
		usuario.setUsuarioNames(user.getUsuarioNames());
		usuario.setUsuarioPassword(user.getUsuarioPassword());
		entityManager.flush();
		flagComplete=true;
		return flagComplete;
	}

	@Override
	public Long totalUsers() {
		// TODO Auto-generated method stub
		StoredProcedureQuery query= entityManager.createStoredProcedureQuery("NP_MANAGEMENT_USER_PKG.SP_GET_TOTAL_USERS");
		query.registerStoredProcedureParameter("AN_TOTAL", Long.class, ParameterMode.OUT);
		query.registerStoredProcedureParameter("AV_MESSAGE", String.class, ParameterMode.OUT);
		query.execute();
		Long AN_TOTAL= (Long)query.getOutputParameterValue("AN_TOTAL");
		return AN_TOTAL;
	}

	@Override
	public List<Usuario> getListCursorUsers(String alias) {
		// TODO Auto-generated method stub
		StoredProcedureQuery query= entityManager.createStoredProcedureQuery("NP_MANAGEMENT_USER_PKG.SP_GET_LIST_USERS",Usuario.class);
		query.registerStoredProcedureParameter(1, void.class, ParameterMode.REF_CURSOR);
		query.registerStoredProcedureParameter(2, String.class, ParameterMode.IN);
		query.registerStoredProcedureParameter(3, String.class, ParameterMode.OUT);
		query.setParameter(2, alias);
		query.execute();
		List<Usuario> listUsers= (List<Usuario>)query.getResultList();
		
		return listUsers;
	}

	
}
