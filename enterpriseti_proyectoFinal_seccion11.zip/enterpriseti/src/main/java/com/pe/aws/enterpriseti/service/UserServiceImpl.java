package com.pe.aws.enterpriseti.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.pe.aws.enterpriseti.dao.UserDao;
import com.pe.aws.enterpriseti.entity.Usuario;

@Service("usuarioService")
public class UserServiceImpl implements UserService{
	
	@Autowired
	@Qualifier("usuarioDao")
	UserDao userDaoImpl;

	@Override
	public List<Usuario> getListUser() {
		// TODO Auto-generated method stub
		return userDaoImpl.getListUser();
	}

	@Override
	public Long addUser(Usuario user) {
		// TODO Auto-generated method stub
		return userDaoImpl.addUser(user);
	}

	@Override
	public Usuario getUser(Long id) {
		// TODO Auto-generated method stub
		return userDaoImpl.getUser(id);
	}

	@Override
	public boolean deleteUser(Long id) {
		// TODO Auto-generated method stub
		return userDaoImpl.deleteUser(id);
	}

	@Override
	public boolean updateUser(Long id, Usuario user) {
		// TODO Auto-generated method stub
		return userDaoImpl.updateUser(id, user);
	}

	@Override
	public Long totalUsers() {
		// TODO Auto-generated method stub
		return userDaoImpl.totalUsers();
	}

	@Override
	public List<Usuario> getListCursorUsers(String alias) {
		// TODO Auto-generated method stub
		return userDaoImpl.getListCursorUsers(alias);
	}

}
