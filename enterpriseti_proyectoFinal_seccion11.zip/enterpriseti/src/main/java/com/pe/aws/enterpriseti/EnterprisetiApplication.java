package com.pe.aws.enterpriseti;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EnterprisetiApplication {

	public static void main(String[] args) {
		SpringApplication.run(EnterprisetiApplication.class, args);
	}
}
