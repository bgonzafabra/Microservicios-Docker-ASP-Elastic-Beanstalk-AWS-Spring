package com.services.people.service;

import java.util.List;

import com.services.people.entity.Usuario;

public interface UsuarioService {
	public List<Usuario> getListUsers();
}
